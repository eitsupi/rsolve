#include <R.h>
#include <Rinternals.h>
#include "../inst/include/middle_marker.h"
SEXP middle_marker(void) { return ScalarInteger(MIDDLE_MARKER_VALUE); }
