middle_value <- function() {
  paste0('middle-', leaf_value())
}
