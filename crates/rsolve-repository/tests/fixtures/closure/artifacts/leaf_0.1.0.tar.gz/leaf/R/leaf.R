leaf_value <- function() {
  'leaf-ok'
}
