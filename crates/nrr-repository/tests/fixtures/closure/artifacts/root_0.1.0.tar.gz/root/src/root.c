#include <R.h>
#include <Rinternals.h>
#include <middle_marker.h>
void root_init(DllInfo *dll) { if (MIDDLE_MARKER_VALUE != 17) error("marker mismatch"); }
